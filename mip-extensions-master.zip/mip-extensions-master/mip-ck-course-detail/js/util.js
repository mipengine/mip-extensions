/**
 * @file: util.js
 * @author: yanglei07
 * @description ..
 * @create data:   2016-10-10 14:52:59
 * @last modified by:   yanglei07
 * @last modified time: 2016-10-24 11:21:45
 */
/* global Vue, _, yog */

define(function (require) {

    var util = {
        domain: '//m.chuanke.com'
        // domain: '//mlocal.chuanke.com'
    };

    return util;
});
