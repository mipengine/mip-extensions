# mip-258-city

mip-258-city 返回组件

标题|内容
----|----
类型|通用
支持布局|fixed
所需脚本|https://c.mipcdn.com/static/v1/mip-258-city/mip-258-city.js

## 示例
### 基本使用

```html
<mip-258-city>
    <select id="province">
        <option value="1">请选择省</option>
    </select>
    <select id="city">
        <option value="1">请选择市</option>
    </select>
    <select id="area">
        <option value="1">请选择区</option>
    </select>
</mip-258-city>
```
## 属性

