# mip-wkad-config

寻医问药广告配置组件

描述|提供了一个广告配置用来显示寻医广告
----|----
类型|广告
支持布局| N/S
所需脚本|https://mipcache.bdstatic.com/static/v1/mip-wkad-config/mip-wkad-config.js

## 示例

只需要一个`<mip-wkad-config>`标签，无须其他填充dom

```
<mip-wkad-config aid="take_ip"></mip-wkad-config>
```

## 属性

### aid

说明：广告配置id
必填：是
格式：字符串
取值：take_ip | display_load | stat
