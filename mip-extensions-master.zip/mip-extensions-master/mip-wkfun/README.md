# mip-wkfun

寻医问药页面功能组件

描述|提供了一些dom操作功能
----|----
类型|dom操作组件
支持布局| N/S
所需脚本|https://mipcache.bdstatic.com/static/v1/mip-wkfun/mip-wkfun.js

## 示例

只需要一个`mip-wkfun标签即可`，无须其他填充dom

```
<mip-wkfun></mip-wkfun>
```
