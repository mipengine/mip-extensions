# mip-xueyou-list

学优网列表插件

描述|列表页加载更多js脚本
----|----
类型|广告
支持布局| N/S
所需脚本| https://mipcache.bdstatic.com/static/v1/mip-xueyou-list/mip-xueyou-list.js

## 示例

只需要一个`<mip-xueyou-list>`标签

```
<mip-xueyou-list></mip-xueyou-list>
```

