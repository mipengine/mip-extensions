# mip-xueyou-ad

mip-xueyou-ad 用来支持淘宝，谷歌广告联盟

标题|内容
----|----
类型|通用
支持布局|container
所需脚本|https://mipcache.bdstatic.com/static/v1/mip-xueyou-ad/mip-xueyou-ad.js

## 示例

```html
<mip-xueyou-ad type="google" token="5396689749"></mip-xueyou-ad>
```

## 属性

### type

说明：广告类型  
必选项：是  
类型：字符串  
格式：必须为 google / alibaba


### token

说明：广告音元ID  
必选项：是  
类型：字符串 
