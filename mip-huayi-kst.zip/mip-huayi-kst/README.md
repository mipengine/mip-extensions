# mip-huayi-kst

华怡MIP站点幻灯片、快商通|商务通邀请框通用推送组件

|标题|内容|
|----|----|
|类型|事件|
|支持布局|N/S|
|所需脚本|https://mipcache.bdstatic.com/static/v1/mip-huayi-kst/mip-huayi-kst.js|

## 示例

在MIP HTML中,直接使用标签, 定义好所属站点账号标识，页面加载完成组件根据页面标识推送幻灯片数据结构，商务通|快商通自定义邀请框展示。

```
<mip-huayi-kst data-siteid="1"></mip-huayi-kst>
```
## 属性

### data-siteid
说明：所属站点ID值
必选项：是
类型：数值
取值范围：无
单位：无
默认值：无
