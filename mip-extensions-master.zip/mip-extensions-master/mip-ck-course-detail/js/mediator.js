/**
 * @file: mediator.js
 * @author: yanglei07
 * @description ..
 * @create data:   2016-10-10 11:29:17
 * @last modified by:   yanglei07
 * @last modified time: 2016-10-10 11:30:41
 */
/* global Vue, _, yog */

define(function (require) {
    var $ = require('zepto');

    return $({});
});
