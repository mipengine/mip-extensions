# mip-xueyou-article

mip-xueyou-article 学优网mip改造插件

标题|内容
----|----
类型|业务
支持布局|N/S
所需脚本|https://mipcache.bdstatic.com/static/v1/mip-xueyou-article/mip-xueyou-article.js

## 示例

### 基本使用
```html
<mip-xueyou-article id='docId' token='token'></mip-xueyou-article>
```

## 属性

### id

说明：唯一编号  
必选项：是  
类型：字符串  


### token

说明：加密编码  
必选项：是  
类型：字符串 
