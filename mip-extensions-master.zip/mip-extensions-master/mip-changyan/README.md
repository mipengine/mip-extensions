# mip-changyan

mip-changyan 用来支持在线评论插件 畅言。

标题|内容
----|----
类型|通用
支持布局|responsive,fixed-height,fill,container,fixed
所需脚本|https://mipcache.bdstatic.com/static/v1/mip-changyan/mip-changyan.js

## 示例

MIP提供支持畅言的扩展组件，代码示例：

```
	<mip-changyan appid="cysjB6Scw" conf="prod_5ca6838c335b62e95ab4306b79f503f5">
			<div id="SOHUCS"></div>
	</mip-changyan>
```

## 属性

### appid

说明：应用id
必选项：是
类型：字符串

### conf

说明：应用key
必选项：是
类型：字符串

