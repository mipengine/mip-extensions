# mip-ckdevice

mip-ckdevice 是用来检测设备屏幕大小并让页面适配的工具

标题|内容
----|----
类型|通用
支持布局| 通用
所需脚本|https://mipcache.bdstatic.com/static/v1/mip-91jm-ckdevice/mip-ckdevice.js

## 示例

无事例样式

## 属性

无

### id

无

### layout

无

## 注意事项

无