# mip-ck-basecss

自有业务逻辑内 MIP 页面的基础css

标题|内容
----|----
类型|业务，定制
支持布局|不使用布局
所需脚本|https://mipcache.bdstatic.com/static/v1.2/mip-ck-basecss.js

## 示例

```html
<mip-ck-basecss></mip-ck-basecss>
```
