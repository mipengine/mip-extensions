# mip-down-hideshow

mip-down-hideshow 用来支持文章详情页的显示隐藏切换

标题|内容
----|----
类型|业务
支持布局|N/S
所需脚本|https://mipcache.bdstatic.com/static/v1/mip-down-hideshow/mip-down-hideshow.js

## 示例

```
<mip-down-hideshow hsId="1">
    <b class="hideshow-btn">点我</b>
</mip-down-hideshow>
```

# 属性

组件涉及的属性字段: 显示隐藏切换位置(hsId)。

### hsId

说明：显示隐藏切换位置   
必填：是  

