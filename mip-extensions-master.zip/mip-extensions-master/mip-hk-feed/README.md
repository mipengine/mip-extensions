﻿# mip-hk-feed

好看feed流

|标题|内容|
|---|---|
|类型|业务|
|支持布局|N/S|
|所需脚本|https://mipcache.bdstatic.com/static/v1/mip-hk-feed/mip-hk-feed.js|

## 示例

在MIP HTML中,直接使用标签, 用于好看信息流。

```
<mip-hk-feed type="video"></mip-hk-feed>
```

## 属性

### type

说明：信息流类型
必选项：否
类型：字符串
取值范围：video
