# mip-258-jump

mip-258-jump 跳转组件

标题|内容
----|----
类型|通用
支持布局|fixed
所需脚本|https://c.mipcdn.com/static/v1/mip-258-jump/mip-258-jump.js

## 示例
### 基本使用

```html
<mip-258-jump></mip-258-jump>
```
## 属性

### method

说明：自动跳转www或者m  
必选项：是 

