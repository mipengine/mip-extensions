# mip-audio

音频播放组件

描述|提供了一个音频播放组件
----|----
类型|通用
支持布局| N/S
所需脚本|https://mipcache.bdstatic.com/static/v1/mip-audio/mip-audio.js

## 示例

```
<mip-audio 
	src="http://cp01-ps-fe-1.epc.baidu.com:8001/javascripts/nicai.mp3"
></mip-audio>
	
```

## 属性

### src

说明：音频地址
必填：是
格式：url
使用限制：必须是https的
