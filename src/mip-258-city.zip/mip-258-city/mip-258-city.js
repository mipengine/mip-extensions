/**
 * @file mip-258-filter 筛选组件
 * @author
 */

 define(function (require) {
    var customElement = require('customElement').create();
    var util = require('util');
    var $ = require('zepto');
    var viewer = require('viewer');

    /**
     * 第一次进入可视区回调，只会执行一次
     */
     customElement.prototype.firstInviewCallback = function () {

     };
     return customElement;
 });
