# mip-cr173-conut

mip-cr173-conut 用来支持下载详情页统计功能

标题|内容
----|----
类型|通用
支持布局|responsive,fixed-height,fill,container,fixed
所需脚本|https://mipcache.bdstatic.com/static/v1/mip-showtanceng/mip-cr173-conut.js
## 示例

### 个人统计
```html
<mip-cr173-conut></mip-cr173-conut>
```


