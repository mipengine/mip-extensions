# mip-39ad

39广告组件

描述|提供了一个广告容器用来显示39广告
----|----
类型|广告
支持布局| N/S
所需脚本|https://mipcache.bdstatic.com/static/v1/mip-39ad/mip-39ad.js

## 示例

只需要一个`<mip-39ad>`标签，无须其他填充dom

```
<mip-39ad asid="3002" hide-layer-id="AdWapAskOnlineFloat" ></mip-39ad>
```

## 属性

### asid

说明：广告id
必填：是   
格式：数字    
取值：4位   

### hide-layer-id

说明：要增加关闭按钮的层的ID
必填：否   
格式：字符串     

