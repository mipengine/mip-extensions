# mip-360doc-script

mip-360doc-script 是360doc网业务逻辑组件。

标题|内容
----|----
类型|业务,广告
支持布局|N/S
所需脚本|https://mipcache.bdstatic.com/static/v1/mip-360doc-script/mip-360doc-script.js

## 示例

### 基本使用

```html
<mip-360doc-script></mip-360doc-script>
```
