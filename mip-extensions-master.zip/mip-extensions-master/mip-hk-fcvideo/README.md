﻿# mip-hk-fcvideo

支持好看详情页凤巢视频播放一段时间提示下载客户端

|标题|内容|
|---|---|
|类型|业务|
|支持布局|N/S|
|所需脚本|https://mipcache.bdstatic.com/static/v1/mip-hk-fcvideo/mip-hk-fcvideo.js|

## 示例

在MIP HTML中,直接使用标签, 用于视频播放一段时间提示下载客户端。

```html
 <mip-hk-fcvideo></mip-hk-fcvideo>
```
