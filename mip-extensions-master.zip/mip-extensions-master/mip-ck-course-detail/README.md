# mip-ck-course-detail

自有业务详情页整体交互组件

标题|内容
----|----
类型|业务，定制
支持布局|不使用布局
所需脚本|https://mipcache.bdstatic.com/static/v1.2/mip-ck-course-detail.js

## 示例

```html
<mip-ck-course-detail></mip-ck-course-detail>
```

## 属性


