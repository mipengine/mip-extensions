# mip-qqtn-mg

mip-qqtn-mg 屏蔽词语

标题|内容
----|----
类型|通用
支持布局|responsive,fixed-height,fill,container,fixed
所需脚本|https://mipcache.bdstatic.com/extensions/platform/v1/mip-qqtn-mg/mip-qqtn-mg.js


## 示例

### 屏蔽词语
```html
<mip-qqtn-mg></mip-qqtn-mg>
```


