# mip-ck-ad 

mip-ck-ad 是康网的问答详情页面的直投广告组件

标题|内容
----|----
类型|业务,广告
支持布局|N/S
所需脚本|https://mipcache.bdstatic.com/static/v1/mip-ck-script/mip-ck-script.js

## 示例

### 基本使用

```html
<mip-ck-script></mip-ck-script>
```
