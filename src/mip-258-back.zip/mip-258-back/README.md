# mip-258-back

mip-258-back 返回组件

标题|内容
----|----
类型|通用
支持布局|fixed
所需脚本|https://c.mipcdn.com/static/v1/mip-258-back/mip-258-back.js

## 示例
### 基本使用

```html
<mip-258-back><div class="btn">返回</div></mip-258-back>
```
## 属性

### method

说明：表单提交方法  
必选项：是 

